import React from "react";
import GoogleMapReact from "google-map-react";
import { useSelector } from "react-redux";
import "./mapPage.css";
import Marker from "./Marker";

const MapPage = () => {
  const myLocation = useSelector((state) => state.map.myLocation);
  const onlineUser = useSelector((state) => state.map.onlineUsers);

  console.log(onlineUser)
  const defaultMapProps = {
    center: {
      lat: myLocation.lat,
      lng: myLocation.lng,
    },
    zoom: 11,
  };
  return (
    <div className="map_page_container">
      <GoogleMapReact
        bootstrapURLKeys={{ key: "" }}
        defaultCenter={defaultMapProps.center}
        defaultZoom={defaultMapProps.zoom}
      >
        {onlineUser.map((mark) => {
          return (
            <Marker
              key={onlineUser.socketId}
              myself={onlineUser.myself}
              socketId={onlineUser.socketId}
              username={onlineUser.username}
              coords={onlineUser.coords}
            />
          );
        })}
      </GoogleMapReact>
    </div>
  );
};

export default MapPage;
