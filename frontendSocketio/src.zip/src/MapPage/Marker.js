import React from "react";
import "./mapPage.css"
import locationIcon from '../resources/images/location-icon.svg'

const Marker =(props)=>{
    const {myself, socketID, username, coords} = props;
    console.log(myself)
    return(
    <div className="map_page_marker_container">
        <img src={locationIcon} alt={username} className="map_page_marker_img"/>
        <p className="map_page_marker_text">{myself ? "me":username}</p>
    </div>
    )
}
 
export default Marker