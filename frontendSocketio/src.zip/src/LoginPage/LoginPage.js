import React, { useEffect, useState } from "react";
import "./LoginPage.css";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setMyLocation } from "../MapPage/mapSlice";
import { connectWithSocketIOServer } from "../socketConnection/socketConnect";
import { proceedWithlogin } from "../store/actions/loginpageaction";

const Logo = () => {
  return <p className="logo">Log</p>;
};

const LoginInput = ({ setUserName, username }) => {
  const handaleValueChange = (e) => {
    setUserName(e.target.value);
  };
  return (
    <input
      className="l_page_input"
      value={username}
      onChange={handaleValueChange}
    ></input>
  );
};

const LoginButton = ({ onClickHandel, disabled }) => {
  return (
    <button
      disabled={disabled}
      className="l_page_login_button"
      onClick={onClickHandel}
    >
      Login
    </button>
  );
};
const LoginPage = () => {
  const dispatch = useDispatch();
  const myLocation = useSelector((state) => state.map.myLocation);
  const [username, setUserName] = useState("");
  const [loactionError, setloactionError] = useState(false);
  const navigate = useNavigate();

  const onSuccess = (postion) => {
    setloactionError(false);
    dispatch(
      setMyLocation({
        lat: postion.coords.latitude,
        lng: postion.coords.longitude,
      })
    );
  };

  useEffect(()=>{
    console.log(username)
  },[username])
  const onError = (error) => {
    setloactionError(true);
  };

  const locationoption = {
    enableHighAccuracy: true,
    timeout: 5000,
    maximumAge: 0,
  };

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      onSuccess,
      onError,
      locationoption
    );
  }, []);

  useEffect(()=>{
    if(myLocation){
        connectWithSocketIOServer()
    }
  },[myLocation])

  const hanglogin = () => {
    proceedWithlogin({
        username:username,
        coords: { lng :myLocation.lat, lat: myLocation.lng}
    })
    navigate("/map");
  };
  return (
    <div className="l_page_main_container">
      <div className="l_page_box">
        <Logo />
        <LoginInput username={username} setUserName={setUserName} />
        <LoginButton disabled={loactionError} onClickHandel={hanglogin} />
      </div>
    </div>
  );
};

export default LoginPage;
