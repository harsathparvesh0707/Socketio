import store from '../store'
import {setOnlineUsers, removeDisconnectedUser} from '../../MapPage/mapSlice'

export const onlineUsersHandler = (socketID,userData)=>{
    store.dispatch(setOnlineUsers(userData.map(user =>{
        if(user.socketID === socketID){
            user.mySelf = true
        }
        return user;
    })))
}

export const userDisconnectedHandler = (socketID)=>{
    store.dispatch(removeDisconnectedUser(socketID))
}
