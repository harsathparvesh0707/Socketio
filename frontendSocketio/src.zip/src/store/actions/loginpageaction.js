import * as Socketconn from "../../socketConnection/socketConnect"
export const proceedWithlogin =(data)=>{
    Socketconn.login(data)
}