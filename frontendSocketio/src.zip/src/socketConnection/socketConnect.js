import io from "socket.io-client"
import { onlineUsersHandler ,userDisconnectedHandler} from "../store/actions/usersActions";
let socket = null;

export const connectWithSocketIOServer= ()=>{
    socket = io('http://localhost:3003/');
    socket.on("connect",()=>{
        console.log("connected with client side ")
    })

    socket.on("online-users",(userData)=>{
        onlineUsersHandler(socket.id,userData)
    })

    socket.on("user-disconnected",(disconnectedscocketID)=>{
        userDisconnectedHandler(disconnectedscocketID)
    })
};

export const login =(data)=>{
    socket.emit("user-login",data)
}
